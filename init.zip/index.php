<?php
	$category = getenv("QUERY_STRING");
	if (!$category) {
		$category = "comic";
	}
	$entrys = array();
	$dirs = dir("./".$category);
	while(false !== ($entry = $dirs->read())){
		if(($entry != '.') && ($entry != '..')) {
			array_push($entrys,$entry);
		}
	}
	$dirs->close();
	$num = rand(0,count($entrys)-1);
	$filepath = "./".$category."/".$entrys[$num];
	ob_clean();
	flush();
	readfile($filepath);
?>
